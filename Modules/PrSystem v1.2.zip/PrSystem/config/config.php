<?php

return [
    'name' => 'PrSystem',
];
