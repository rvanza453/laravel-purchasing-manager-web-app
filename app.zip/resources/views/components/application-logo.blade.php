<img src="{{ asset('images/saraswantiLogo.png') }}" {{ $attributes }} alt="Saraswanti Logo">
